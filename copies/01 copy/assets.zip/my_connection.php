<?php


$my_connection = mysqli_connect("localhost","skenjlgk_assest", "skenjlgk_assest", "skenjlgk_assest") or die(mysqli_error($my_connection));
?>