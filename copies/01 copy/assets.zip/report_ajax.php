<?php require_once('my_connection.php');
// all Assets (Items) Date Wise Report
if (isset($_POST['from_date']) && isset($_POST['to_date'])) {
    $get_from_date = $_POST['from_date'];
    $get_to_date   = $_POST['to_date'];

   $from_date = date("y-m-d", strtotime($get_from_date));
   $to_date = date("y-m-d", strtotime($get_to_date));
  //$productId   = $_POST['productId'];
?>

<div class="row">
                    <div class="col-sm-12">
                       
                            <!-- <h4 class="m-t-0 header-title"><b>Total Assets (ITEMS) List</b></h4> -->
                            <center> <h3 class="m-t-0 header-title"><strong>Total Assets (ITEMS) List</strong></h3>
                            <div class="row">
                                <span><b>From : </b><?php echo $head_from_date = date("y-M-d", strtotime($from_date)); ?></span> ||   <span><b>To : </b><?php echo $head_to_date = date("y-M-d", strtotime($to_date)); ?></span>
                                
                            </div>
                            <br>
                            </center>
                            

                            <!-- <table id="datatable-buttons" class="table table-striped table-bordered"> -->
                            <!-- <table id="datatable" class="table table-striped table-bordered"> -->

                            <div class="table-responsive my-only-div-shadow py-4">
                            <!-- export_table -->
         <!-- for bootstrape datatable <table class="table table-bordered data_table table-striped"  id="customers" data-page-length="50"> -->
  
         <table id="customers" class="table table-striped table-bordered export" style='width:100%;font-family:Calibri;
  border-collapse: collapse;
  width: 100%;'>
                                <thead>
                                <tr>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Serial #</th>
                                    
                                    
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Supplier</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Item Type</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">PO No</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Item Name</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Item No</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Unit</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Unit Price</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Quantity</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Total Amount</th>
                                     <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Discription</th>
  <!--                                   <th style="padding-top: 12px;-->
  <!--padding-bottom: 12px;-->
  <!--text-align: center;-->
  <!--background-color: #4CAF50;-->
  <!--color: white;border: 1px solid #ddd;">File</th>-->
                                 
                                </tr>
                                </thead>


                                <tbody>
                 <?php 

                   $today = date("Y-m-d");
              
 $select_qry2 = mysqli_query($my_connection, "select a.*,s.name,c.title as category_name,i.unit,i.item_name from assets a 
                                              join suppliers s on a.supplier_id = s.id
                                              join categories c on a.category_id = c.id
                                              join items i on a.item_id = i.id 
                                              where a.dated BETWEEN '$from_date' AND '$to_date'") or die(mysqli_error($my_connection));
                                $n = 1;
                                  while($row2 = mysqli_fetch_array($select_qry2)){
                                  $id = $row2['id'];

                           
                             echo ' <tr role="row" class="odd">';
                                    
                                    echo '<td style="border: 1px solid #ddd;"> '.$n++.'</td>';

                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['name'].'</b>';
                                    echo '</td>';

                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['category_name'].'</b>';
                                    echo '</td>';
                                        
                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['po_no'].'</b>';
                                    echo '</td>';
                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo '<b>'.$row2['item_name'].'</b>';
                                          echo '</td>';

                                          echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['item_no'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['unit'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                           echo $row2['price'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['quantity'];
                                          echo '</td>';
                                          
                                            echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['total_amount'];
                                          echo '</td>';

                                          echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['description'];
                                          echo '</td>';


        //                                   echo  '<td style="border: 1px solid #ddd;">';
                                         
        //     echo ' <div class="media-left">
        //     <a href="#"> <img class="media-object img-circle" alt="Image Not yet Added" src="'.$row2['file_path'].'" style="width: 74px; height: 74px;"> </a>
        // </div>';
  
        //                                     echo '</td>'; 

                                     echo '</tr>';

                          
                            }
                   ?> 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <?php }

                // all Assets (Items) Date/Category Wise Report
if (isset($_POST['c_from_date']) && isset($_POST['c_to_date']) && isset($_POST['category_id'])) {
    $get_from_date = $_POST['c_from_date'];
    $get_to_date   = $_POST['c_to_date'];
    $category_id   = $_POST['category_id'];

   $from_date = date("y-m-d", strtotime($get_from_date));
   $to_date = date("y-m-d", strtotime($get_to_date));

   $select_qry = mysqli_query($my_connection, "SELECT * FROM `categories` where id ='$category_id'") or die(mysqli_error($my_connection));
   $row = mysqli_fetch_assoc($select_qry);
   $title = @$row['title'];
?>

<div class="row">
                    <div class="col-sm-12">
                       
                            <!-- <h4 class="m-t-0 header-title"><b>Total Assets (ITEMS) List</b></h4> -->
                            <center> <h3 class="m-t-0 header-title"><strong>Total Assets (ITEMS) List Category (<?php if($title != ' '){ echo @$title; } else { } ?>  )</strong></h3>
                            <div class="row">
                                <span><b>From : </b><?php echo $head_from_date = date("y-M-d", strtotime($from_date)); ?></span> ||   <span><b>To : </b><?php echo $head_to_date = date("y-M-d", strtotime($to_date)); ?></span>
                                
                            </div>
                            <br>
                            </center>
                            

                            <!-- <table id="datatable-buttons" class="table table-striped table-bordered"> -->
                            <!-- <table id="datatable" class="table table-striped table-bordered"> -->

                            <div class="table-responsive my-only-div-shadow py-4">
                            <!-- export_table -->
         <!-- for bootstrape datatable <table class="table table-bordered data_table table-striped"  id="customers" data-page-length="50"> -->
  
         <table id="customers" class="table table-striped table-bordered export" style='width:100%;font-family:Calibri;
  border-collapse: collapse;
  width: 100%;'>
                                <thead>
                                <tr>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Serial #</th>
                                    
                                    
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Supplier</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Category</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">PO No</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Item Name</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Item No</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Unit</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Unit Price</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Quantity</th>
                                    <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Total Amount</th>
                                     <th style="padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;border: 1px solid #ddd;">Discription</th>
  <!--                                   <th style="padding-top: 12px;-->
  <!--padding-bottom: 12px;-->
  <!--text-align: center;-->
  <!--background-color: #4CAF50;-->
  <!--color: white;border: 1px solid #ddd;">File</th>-->
                                  <!-- <th>Actions</th> -->
                                </tr>
                                </thead>


                                <tbody>
                 <?php 

                   $today = date("Y-m-d");
              
 $select_qry2 = mysqli_query($my_connection, "select a.*,s.name,c.title as category_name,i.unit,i.item_name from assets a 
                                              join suppliers s on a.supplier_id = s.id
                                              join categories c on a.category_id = c.id
                                              join items i on a.item_id = i.id 
                                              where a.category_id = '$category_id' and a.dated BETWEEN '$from_date' AND '$to_date'") or die(mysqli_error($my_connection));
                                $n = 1;
                                  while($row2 = mysqli_fetch_array($select_qry2)){
                                  $id = $row2['id'];

                           
                             echo ' <tr role="row" class="odd">';
                                    
                                    echo '<td style="border: 1px solid #ddd;"> '.$n++.'</td>';

                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['name'].'</b>';
                                    echo '</td>';

                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['category_name'].'</b>';
                                    echo '</td>';
                                        
                                    echo  '<td style="border: 1px solid #ddd;">';
                                    echo '<b>'.$row2['po_no'].'</b>';
                                    echo '</td>';
                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo '<b>'.$row2['item_name'].'</b>';
                                          echo '</td>';

                                          echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['item_no'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['unit'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                           echo $row2['price'];
                                          echo '</td>';

                                           echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['quantity'];
                                          echo '</td>';
                                          
                                            echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['total_amount'];
                                          echo '</td>';

                                          echo  '<td style="border: 1px solid #ddd;">';
                                          echo $row2['description'];
                                          echo '</td>';


        //                                   echo  '<td style="border: 1px solid #ddd;">';
                                         
        //     echo ' <div class="media-left">
        //     <a href="#"> <img class="media-object img-circle" alt="Image Not yet Added" src="'.$row2['file_path'].'" style="width: 74px; height: 74px;"> </a>
        // </div>';
  
        //                                     echo '</td>'; 

                                     echo '</tr>';

                          
                            }
                   ?> 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


                <?php }

// all Assets (Items) Date/Category Wise Report
if (isset($_POST['d_from_date']) && isset($_POST['d_to_date']) && isset($_POST['department_id'])) {
$get_from_date = $_POST['d_from_date'];
$get_to_date   = $_POST['d_to_date'];
$department_id   = $_POST['department_id'];

$from_date = date("y-m-d", strtotime($get_from_date));
$to_date = date("y-m-d", strtotime($get_to_date));
//$productId   = $_POST['productId'];

$select_qry = mysqli_query($my_connection, "SELECT * FROM `departments` where id ='$department_id'") or die(mysqli_error($my_connection));
$row = mysqli_fetch_assoc($select_qry);
$title = @$row['title'];
?>

<div class="row">
    <div class="col-sm-12">
       
            <!-- <h4 class="m-t-0 header-title"><b>Total Assets (ITEMS) List</b></h4> -->
            <center> <h3 class="m-t-0 header-title"><strong>Issue Assets (ITEMS) List Department (<?php if($title != ' '){ echo @$title; } else { } ?> )</strong></h3>
            <div class="row">
                <span><b>From : </b><?php echo $head_from_date = date("y-M-d", strtotime($from_date)); ?></span> ||   <span><b>To : </b><?php echo $head_to_date = date("y-M-d", strtotime($to_date)); ?></span>
                
            </div>
            <br>
            </center>
            

            <!-- <table id="datatable-buttons" class="table table-striped table-bordered"> -->
            <!-- <table id="datatable" class="table table-striped table-bordered"> -->

            <div class="table-responsive my-only-div-shadow py-4">
            <!-- export_table -->
<!-- for bootstrape datatable <table class="table table-bordered data_table table-striped"  id="customers" data-page-length="50"> -->

<table id="customers" class="table table-striped table-bordered export" style='width:100%;font-family:Calibri;
border-collapse: collapse;
width: 100%;'>
                <thead>
                <tr>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Serial #</th>
                    
                    
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Item Name</th>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Employee Name</th>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Department</th>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Issue Quantity</th>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Issue Date</th>
                    <th style="padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #4CAF50;
color: white;border: 1px solid #ddd;">Description</th>
<!--                    <th style="padding-top: 12px;-->
<!--padding-bottom: 12px;-->
<!--text-align: center;-->
<!--background-color: #4CAF50;-->
<!--color: white;border: 1px solid #ddd;">File</th>-->
                </tr>
                </thead>


                <tbody>
 <?php 

   $today = date("Y-m-d");

$select_qry2 = mysqli_query($my_connection, "SELECT ia.*, i.item_name, d.title, e.name
FROM issue_assets ia
JOIN assets a ON ia.assets_id = a.id
JOIN departments d ON ia.department_id = d.id
JOIN employees e ON ia.employee_id = e.id
JOIN items i ON a.item_id = i.id
                              where ia.department_id = '$department_id' and ia.issue_date BETWEEN '$from_date' AND '$to_date'") or die(mysqli_error($my_connection));
                $n = 1;
                  while($row2 = mysqli_fetch_array($select_qry2)){
                  $id = $row2['id'];

           
             echo ' <tr role="row" class="odd">';
                    
                    echo '<td style="border: 1px solid #ddd;"> '.$n++.'</td>';

                    echo  '<td style="border: 1px solid #ddd;">';
                    echo '<b>'.$row2['item_name'].'</b>';
                    echo '</td>';

                    echo  '<td style="border: 1px solid #ddd;">';
                    echo '<b>'.$row2['name'].'</b>';
                    echo '</td>';
                        
                    echo  '<td style="border: 1px solid #ddd;">';
                    echo '<b>'.$row2['title'].'</b>';
                    echo '</td>';
                           echo  '<td style="border: 1px solid #ddd;">';
                          echo '<b>'.$row2['quantity'].'</b>';
                          echo '</td>';

                          echo  '<td style="border: 1px solid #ddd;">';
                          $row2['issue_date'];
                          echo $date = date("j F, Y", strtotime($row2['issue_date']));
                          echo '</td>';

                           echo  '<td style="border: 1px solid #ddd;">';
                          echo $row2['description'];
                          echo '</td>';


//                           echo  '<td style="border: 1px solid #ddd;">';
                         
// echo ' <div class="media-left">
// <a href="#"> <img class="media-object img-circle" alt="Image Not yet Added" src="'.$row2['file_path'].'" style="width: 74px; height: 74px;"> </a>
// </div>';

//                             echo '</td>'; 

                     echo '</tr>';

          
            }
   ?> 
                
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php }

?>