

<?php
require_once('my_connection.php');
if($_POST['department_id'])
{
$department_id=$_POST['department_id']; 
$sql=mysqli_query($my_connection, "select id,name from employees 
where department_id = '$department_id'");
while($row=mysqli_fetch_array($sql))
{


$id=$row['id'];
$name=$row['name'];

 echo '<option value="'.$id.'">'.$name.'</option>';

// echo ' <input type="number" class="form-control quantity" value="'.$quantity.'" name = "quantity" readonly />';
}
}

  
  
?>
