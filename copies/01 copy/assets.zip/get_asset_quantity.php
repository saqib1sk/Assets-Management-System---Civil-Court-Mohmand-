

<?php
require_once('my_connection.php');
if($_POST['id'])
{
$id=$_POST['id']; 
$sql=mysqli_query($my_connection, "select asset_id,quantity from asset_available 
where asset_id = '$id'");
while($row=mysqli_fetch_array($sql))
{


$id=$row['asset_id'];
$quantity=$row['quantity'];
// echo '<option value="">Select Designation</option>';

echo ' <input type="number" class="form-control current_qty" id="current_qty" value="'.$quantity.'" name = "current_qty" readonly />';

}
}
?>
