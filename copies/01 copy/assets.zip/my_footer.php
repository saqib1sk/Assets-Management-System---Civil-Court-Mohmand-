 <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-6">
                                © 2023. All rights reserved.
                            </div>
                            <div class="col-xs-6">
                                 <div class="credits" style="float:right;">
                                 Designed & Devloped by <a href="https://mindgigspk.com/" target="_blank">MINDGIGS</a>
          </div>
                              <!--   <ul class="pull-right list-inline m-b-0">
                                    <li>
                                        <a href="#">About</a>
                                    </li>
                                    <li>
                                        <a href="#">Help</a>
                                    </li>
                                    <li>
                                        <a href="#">Contact</a>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                    </div>
                </footer>