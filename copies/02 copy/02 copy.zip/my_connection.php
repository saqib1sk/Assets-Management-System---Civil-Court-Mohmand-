<?php


$my_connection = mysqli_connect("localhost","root", "", "assets_management_system_db") or die(mysqli_error($my_connection));
?>