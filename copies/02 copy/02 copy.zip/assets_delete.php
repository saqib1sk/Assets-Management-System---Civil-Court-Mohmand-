<?php
 require_once('my_connection.php');
 


  if(isset($_GET['id'])){
        $id = $_GET['id'];
 //die();
 
$sql=mysqli_query($my_connection, "DELETE FROM `assets` where id = '$id'")  or die(mysqli_error($my_connection));


$sql1=mysqli_query($my_connection, "DELETE FROM `asset_available` where asset_id = '$id'")  or die(mysqli_error($my_connection));

 header('location:assets.php?msg=deleted');
}

                                                                               
?>