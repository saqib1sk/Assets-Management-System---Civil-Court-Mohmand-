<?php
require_once('session_data.php');

?>

<?php
    require_once('my_connection.php');
    $warning = '';
    $success = '';
   // $message='';
  if(isset($_POST['btnsave'])){
         $po_no = $_POST['po_no'];
         // $item_no = $_POST['item_no'];
         $item_id = $_POST['item_id'];
         $purchase_order_invoice_no = $_POST['purchase_order_invoice_no'];
         $price = $_POST['price'];
         $quantity = $_POST['quantity'];
         $total_amount = $_POST['total_amount'];
         $description = $_POST['description'];
         $dated = $_POST['dated'];
         $supplier_id = $_POST['supplier_id'];
         $category_id = $_POST['category_id'];

          $last_item_id = $po_no;
     

   //  die();
          $check_qry = mysqli_query($my_connection, "SELECT   `item_id`  FROM `assets` WHERE  item_id = '$item_id'") or die (mysqli_error($my_connection));
 $num_rows = mysqli_num_rows($check_qry); 
 if($num_rows == 0){

    $target_dir = "assets_images/";
  if(@$_FILES["upload_file"]["name"][0] != null){
         
      $file_name =  $_FILES['upload_file']['name']; 
      $file_type = $_FILES['upload_file']['type']; 
      $file_size = $_FILES['upload_file']['size']; 
      $tmp_name = $_FILES['upload_file']['tmp_name'];
      $explode_file_name = explode('.',$file_name); 
    $file_extension = strtolower(end($explode_file_name));
    $file_new_name = uniqid().'.'.$file_extension;
    $path = $target_dir.$file_new_name;
   
      if($file_extension == 'jpg' or $file_extension == 'png'  or $file_extension == 'jpeg'  or $file_extension == 'PNG'  or $file_extension == 'JPG'  or $file_extension == 'JPEG'){
        
        if(move_uploaded_file($tmp_name, $path)){
         // $remove_character = substr($path, 3);



 $insert_qry = "INSERT INTO `assets`(`purchase_order_invoice_no`,`supplier_id`,`category_id`,`po_no`,`item_no`, `item_id`, `price`, `quantity`, `total_amount`, `description`,`file_path`, `dated`) 
                             VALUES ('$purchase_order_invoice_no','$supplier_id','$category_id','$po_no',' ','$item_id','$price','$quantity','$total_amount','$description','$path','$dated')"; 
    mysqli_query($my_connection, $insert_qry) or die(mysqli_error($my_connection));
    $lastInsertID = mysqli_insert_id($my_connection);
    $insert_qry = "INSERT INTO `asset_available`(`asset_id`,`category_id`, `quantity`) VALUES ('$lastInsertID','$category_id','$quantity')"; 
    mysqli_query($my_connection, $insert_qry) or die(mysqli_error($my_connection));


 $new_id = $last_item_id+1;
    $update = "UPDATE item_id SET item_id = '$new_id'";
    mysqli_query($my_connection, $update);

        $success = '<div class="alert alert-success alert-block alert-dismissible fade in iconic-alert" role="alert">
                                    <div class="alert-icon">
                                        <span class="gcon gcon-emoji-happy centered-xy"></span>
                                    </div>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><span class="mcon mcon-close"></span></span></button>
                                    <strong>Success!</strong> Record Inserted.
                            </div>'; 
}
      }
else{   
 $warning = '<div class="alert alert-danger alert-block alert-dismissible fade in iconic-alert" role="alert">
                                    <div class="alert-icon">
                                        <span class="gcon gcon-hand centered-xy"></span>
                                    </div>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><span class="mcon mcon-close"></span></span></button>
                                    <strong>Oh snap!</strong> Record Already exist
                                </div>';  
}
   }

   else{



  //insert here with out image...

  $insert_qry1 = "INSERT INTO `assets`(`purchase_order_invoice_no`,`supplier_id`,`category_id`,`po_no`,`item_no`, `item_id`, `price`, `quantity`, `total_amount`, `description`,`file_path`, `dated`) 
  VALUES ('$purchase_order_invoice_no','$supplier_id','$category_id','$po_no',' ','$item_id','$price','$quantity','$total_amount','$description','FILE NOT YET ADDED','$dated')"; 
mysqli_query($my_connection, $insert_qry1) or die(mysqli_error($my_connection));
$lastInsertID = mysqli_insert_id($my_connection);
$insert_qry1 = "INSERT INTO `asset_available`(`asset_id`,`category_id`, `quantity`) VALUES ('$lastInsertID','$category_id','$quantity')"; 
mysqli_query($my_connection, $insert_qry1) or die(mysqli_error($my_connection));
 

  $new_id = $last_item_id+1;
    $update = "UPDATE item_id SET item_id = '$new_id'";
    mysqli_query($my_connection, $update);

$success = '<div class="alert alert-success alert-block alert-dismissible fade in iconic-alert" role="alert">
                                <div class="alert-icon">
                                    <span class="gcon gcon-emoji-happy centered-xy"></span>
                                </div>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><span class="mcon mcon-close"></span></span></button>
                                <strong>Success!</strong> Record Inserted With Out Image.
                        </div>';
}    
    
     

}
else{
$warning = '<div class="alert alert-danger alert-block alert-dismissible fade in iconic-alert" role="alert">
                                <div class="alert-icon">
                                    <span class="gcon gcon-hand centered-xy"></span>
                                </div>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><span class="mcon mcon-close"></span></span></button>
                                <strong>Oh snap!</strong> Record Already exist
                            </div>';

}

} 
?>

  
<!DOCTYPE html>
<html>
<title>Find Child</title>
    

<?php require_once('my_meta.php'); ?>


    <body>


        <!-- Navigation Bar-->
        <head>
        
         
         <?php require_once('my_header.php'); ?>
        
        <link href="assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
           <!-- DataTables link files -->
         <?php require_once('datatable_link_files.php'); ?>
           <!-- DataTables link files end -->

           <script src="dist/jquery.js"></script>
           <script type="text/javascript">
// get item_name from items table by category_id
$(document).ready(function()
{
$(".category").change(function()
{
   
var id=$(this).val();
//alert(id);
var dataString = 'id='+ id;
$.ajax
({
type:"POST",
url: "get_item.php",
data: dataString,
cache: false,
success: function(html)
{
$(".item").html(html);
} 
});
});
});
</script>


        </head>
        
       
        <!-- End Navigation Bar-->


        <div class="wrapper">
            <div class="container">
            
            
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="btn-group pull-right m-t-15">
                          
                        </div>

                        <h4 class="page-title">Add Stock</h4>
                        <ol class="breadcrumb">
                        
                        </ol>
                    </div>
                </div>


                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            
                            
                            <div class="row">
                            <?php echo $success; ?>
            <?php echo $warning; ?>

             <?php
                $query = "SELECT * FROM item_id";
                $result = mysqli_query($my_connection, $query);
                $rowData = mysqli_fetch_array($result);
                $last_item_id = $rowData['item_id'];
              ?>
                                <div class="col-md-12">
   <form class="" role="form" method="post" enctype="multipart/form-data">
                                        
                                        
                                        <div class="row">
                                           

                                            <div class="form-group col-md-3">
                                            <label class=" control-label"> Purchase Order/Invoice No</label>
                                            <div class="">
                                                <input type="text" class="form-control" placeholder="" name = "purchase_order_invoice_no" required />
                                            </div>
                                        </div>

                                          <div class="form-group col-md-3">
                                            <label class=" control-label">Date</label>
                                            <div class="">
                                                <input type="date" class="form-control" placeholder="" name = "dated" required />
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Select Vendor </label>
                                            <span><a href="supplier_add.php"><small style="float:right; color:#2e79be;" class="text-muted" >Add Vendor</small></a></span>
                                            <div class="">
                                            <select name="supplier_id" class="form-control"  tabindex="">
                                               <option value="">Select Vendor</option>
                                           <?php $select_qry = mysqli_query($my_connection,"select * from suppliers") or die (mysqli_error($my_connection)); 
                                           while($row=mysqli_fetch_array($select_qry)){
                                            $id =  $row['id'];
                                            $name = $row['name'];
                                            echo "<option value = '$id'>$name</option>";
                                           }
                                           
                                            ?>
                                           </select>
                                            </div>
                                        </div>

                                   

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Select Category </label>
                                            <span><a href="category_add.php"><small style="float:right; color:#2e79be;" class="text-muted" >Add Category</small></a></span>
                                            <div class="">
                                            <select name="category_id" class="form-control category"  tabindex="">
                                               <option value="">Select Category</option>
                                           <?php $select_qry = mysqli_query($my_connection,"select * from categories") or die (mysqli_error($my_connection)); 
                                           while($row=mysqli_fetch_array($select_qry)){
                                            $id =  $row['id'];
                                            $title = $row['title'];
                                            echo "<option value = '$id'>$title</option>";
                                           }
                                           
                                            ?>
                                           </select>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Item Name</label>
                                            <span><a href="item_add.php"><small style="float:right; color:#2e79be;" class="text-muted" >Add Item</small></a></span>
                                            <div class="">
                                            <select name="item_id" class="form-control item"  tabindex="">
                                               <option value="">Select Item</option>
                                           </select>
                                            </div>
                                        </div>

                                      <div class="form-group col-md-3">
                                            <label class=" control-label">Item ID</label>
                                            <div class="">
                         <input type="number" class="form-control" placeholder="" name = "po_no" required value="<?php echo $last_item_id ?>" readonly />
                                            </div>
                                        </div>
<!-- 
                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Item No</label>
                                            <div class="">
                                                <input type="text" class="form-control" placeholder="" name = "item_no" required />
                                            </div>
                                        </div> -->

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Price Per Unit</label>
                                            <div class="">
                                                <input type="text" class="form-control" id="price" placeholder="" name = "price"  required/>
                                            </div>
                                        </div>

                                          <div class="form-group col-md-3">
                                            <label class=" control-label">Quantity</label>
                                            <div class="">
                                                <input type="text" class="form-control" id="quantity" placeholder="" name = "quantity" required onkeyup="calculate_amount()"/>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Total Amount</label>
                                            <div class="">
                                                <input type="text" class="form-control" placeholder="" id="total_amount" name = "total_amount" required readonly />
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class=" control-label">Remarks</label>
                                            <div class="">
                                                <textarea  type="text" class="form-control" placeholder="" name = "description" required rows="" cols=""></textarea>
                                            </div>
                                        </div>

                                      

                                        <div class="form-group col-md-3">
                                          <label class=" control-label"></label>
                                                <div class="">                                                                                            
                                                    <!-- <input type="file" name = "upload_file" value = "" /> -->
<input id="file" type="file" name="upload_file" onchange="showImage1(event)" t accept="image/*" class="form-control" style="overflow: hidden;" placeholder="Insert Your Image">
<img id="img" class="shadow" style="float:right; border: 1px blue solid; border-radius: 10%; margin-top: 4%" width="130px;" src="assets/images/file.PNG" height="130px" alt="Image">
                                                </div>

                                            </div>

                                                </div>
                                        
                                        
<label class=" control-label col-m-12"></label>
<div class="form-group" style="float: right;">
<button type="submit" class="btn btn-success waves-effect waves-light m-l-8 btn-md" name ="btnsave" >ADD</button>
</div>

                                    </form>
                                
                                </div>

                                


                            </div>
                        </div>
                    </div>
                </div>



                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            <h4 class="m-t-0 header-title"><b>Stock List</b></h4>
                            

                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Serial #</th>
                                    <th>Purchase Order/Invoice No.</th>
                                    <th>Delivery Date</th>
                                    
                                    
                                    <th>Vendor</th>
                                    <th>Item Name & ID</th>
                                   
                                    <!-- <th>Item Name</th>
                                     <th>Item ID</th> -->
                                    <!-- <th>Item No</th> -->
                                    <!-- <th>Unit</th> -->
                                    <th>Price Per Unit</th>
                                    <th>Quantity</th>
                                    <!-- <th>Total Amount</th> -->
                                     <th>Remarks</th>
                                     <th>File</th>
                                  <th>Actions</th>
                                </tr>
                                </thead>


                                <tbody>
                 <?php 

                   $today = date("Y-m-d");
              
 $select_qry2 = mysqli_query($my_connection, "select a.*,s.name,c.title as category_name,i.unit,i.item_name from assets a 
                                              join suppliers s on a.supplier_id = s.id
                                              join categories c on a.category_id = c.id
                                              join items i on a.item_id = i.id") or die(mysqli_error($my_connection));
                                $n = 1;
                                  while($row2 = mysqli_fetch_array($select_qry2)){
                                  $id = $row2['id'];

                           
                             echo ' <tr role="row" class="odd">';
                                    
                                    echo '<td> '.$n++.'</td>';
                                     echo  '<td class="">';
                                    echo '<b>'.$row2['purchase_order_invoice_no'].'</b>';
                                    echo '</td>';

                                    
                                               echo  '<td class="">';
                                 $row2['dated'];
                                           echo $date = date("j F, Y", strtotime($row2['dated']));

                                    echo '</td>';


                                       

                                    echo  '<td class="">';
                                    echo '<b>'.$row2['name'].'</b>';
                                    echo '</td>';

                                      echo  '<td class="">';
                                          echo '<b>'.$row2['item_name']. '<br>ID : '.$row2['po_no'].' </b>';
                                          echo '</td>';


                                    

                                    // echo  '<td class="">';
                                    // echo '<b>'.$row2['category_name'].'</b>';
                                    // echo '</td>';
                                        
                                  
                                          
                                   // echo  '<td class="">';
                                   //  echo '<b>'.$row2['po_no'].'</b>';
                                   //  echo '</td>';
                                          // echo  '<td class="">';
                                          // echo $row2['item_no'];
                                          // echo '</td>';

                                          //  echo  '<td class="">';
                                          // echo $row2['unit'];
                                          // echo '</td>';

                                           echo  '<td class="">';
                                           echo $row2['price'];
                                          echo '</td>';

                                           echo  '<td class="">';
                                          echo $row2['quantity'];
                                          echo '</td>';
                                          
                                          //   echo  '<td class="">';
                                          // echo $row2['total_amount'];
                                          // echo '</td>';

                                          echo  '<td class="">';
                                          echo $row2['description'];
                                          echo '</td>';


                                          echo  '<td class="">';
                                          //  echo $row2['image_path'];
  
                                          //   echo ' <a  href ="'.$row2['image_path'].'" style="margin-left:18px; align:bottom;" data-toggle="tooltip" data-placement="bottom" title="Download/View File">
                                          //    <i class="fa fa-image" style="font-size:30px;color:#094769; margin-top:0px;"></i>';
            echo ' <div class="media-left">
            <a href="#"> <img class="media-object img-circle" alt="Image Not yet Added" src="'.$row2['file_path'].'" style="width: 74px; height: 74px;"> </a>
        </div>';
  
                                            echo '</td>'; 

                                          
                                       echo '<td style="width:90px;">';
                                    //  echo '</a>';
                                
                                   echo ' <a href="#" >
                                   
                                        
                             <a  href ="assets_edit.php?id='.$id.'" data-toggle="tooltip" data-placement="bottom" title="Edit" style=""> 
                                <i class="ti-pencil" style="font-size:25px; color:success; margin-top:10px; margin-left:0px;"></i>
                                 </a> 
                                 |
                                 <a  href ="assets_delete.php?id='.$id.'" data-toggle="tooltip" data-placement="bottom" title="Delete" style=""> 
                                <i class="ti-trash" style="font-size:25px; color:red; margin-top:10px; margin-left:0px;"></i>
                                 </a>
                
                                 ';
                                            echo '</td>';
                                     echo '</tr>';

                          
                            }
                   ?> 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Footer -->
                <?php require_once('my_footer.php'); ?>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div> <!-- end wrapper -->
        <!-- jQuery  -->
       <?php require_once('jq_files.php'); ?>
        <!--End jQuery  -->
         <!-- datatable_script_files -->
                <?php require_once('datatable_script_files.php'); ?>
                <!-- End datatable_script_files --> 
    </body>
</html>

<script>
  var showImage1 = function(event) {
  var uploadField = document.getElementById("file");
  //alert("hello");
  if (uploadField.files[0].size > 900000) {
  uploadField.value = "";
  Swal.fire(
  'Error !',
  'File Size is too big! Upload logo under 900kB !',
  'error'
  ).then((result) => {
  if (result.isConfirmed) {}
  });
  } else {
  var logoId = document.getElementById('img');
  logoId.src = URL.createObjectURL(event.target.files[0]);
  }
  }


  function calculate_amount() {
    var price = parseInt($('#price').val());
    var quantity = parseInt($('#quantity').val());
    if (isNaN(quantity)) {
        $('#total_amount').val('');
    } else {
        var total = price * quantity;
        $('#total_amount').val(total);
    }

}

  </script>