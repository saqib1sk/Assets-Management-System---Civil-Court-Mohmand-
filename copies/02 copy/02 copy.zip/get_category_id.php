

<?php
require_once('my_connection.php');
if($_POST['id'])
{
$id=$_POST['id']; 
$sql=mysqli_query($my_connection, "select category_id from assets 
where id = '$id'");
while($row=mysqli_fetch_array($sql))
{


//$id=$row['asset_id'];
$category_id=$row['category_id'];
// echo '<option value="">Select Designation</option>';

echo ' <input type="number" class="form-control category_id" id="category_id" value="'.$category_id.'" name = "category_id" readonly />';

}
}
?>
